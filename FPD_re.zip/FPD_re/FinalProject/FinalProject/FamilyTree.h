#pragma once
#ifndef FamilyTree_H
#define FamilyTree_H

#include <vector>
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;

enum Gender{male, female};

class Person
{
	string name;
	Gender gender;
	vector<Person *> parents; //infinite child nodes
	vector<Person *> children; //infinite parent nodes
	void addParent(Person *p) { parents.push_back(p); }
public:
	Person(string name, Gender g)
	{
		this->name = name;
		gender = g;
	}
	Person *addChild(string name, Gender g);
	Person *addChild(Person *p);

	friend ostream &operator << (ostream &out, Person p);

	//I added this one so a person's data could be editted
	//it would be possible but not worth while timewise as of typing this
	//to also allow for parent and children modification through this function
	void editNameGender(string name, Gender g)
	{
		this->name = name;
		gender = g;
	}

	string getName() const { return name; };
	Gender getGender() const { return gender; };
	int getNumChildren() const { return children.size(); }
	int getNumParents() const { return parents.size(); }
	Person *getChild(int k) const;
	Person *getParent(int k) const;
};
#endif FamilyTree_H