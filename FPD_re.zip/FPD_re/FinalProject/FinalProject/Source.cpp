//  ****************************************************************************
//  *                                                                          *
//  *  Programmer(s): William J. Heine                                         *
//  *  Program:       Final Project			                                   *
//  *  Source cpp:    Source.cpp                                               *
//  *							                                               *
//  *  Other files:	  FamilyTree.h                                             *
//  *                 output.txt                                               *
//  *                                                                          *
//  *  School:        St. Louis Community College                              *
//  *  Class:         IS 275 267 Advanced C++ Programming                      *
//  *  Instructor:    David Doering                                            *
//  *  Assigned Date: 01 May 2018	                                           *
//  *  Due Date:      08 May 2018	                                           *
//  *                                                                          *
//  *  Purpose:       Program allows you to create a genealogy tree            *
//  *                                                                          *
//  *                                                                          *
//  *  Input:         User                                                     *
//  *                                                                          *
//  *  Processing:    DescribeInAFewSentencesTheMajorCalculations              *
//  *                 AndOtherProcessingProgramDoes                            *
//  *                                                                          *
//  *  Output:        Screen and Output.txt                                    *
//  *                                                                          *
//  *                                                                          *
//  *  Additional:    This program was based off of the program 19.5.          *
//  *  Noticing that it had the capability to handle much more than the        *
//  *  program demo showed, I adapted it to handle an "infinite" number        *
//  *  of people. The Boon of vectors for parental and child nodes allows      *
//  *  any number of children or parents to be entered. Adding my own vector   *
//  *  in main for all the people created allowed me to create the infinite    *
//  *  people, but also linearly search the vector. This allowed me to make    *
//  *  a function to link any three people in 1 search of the list. The        *
//  *  overloaded ostream operator was a bain and a boon. First, it does       *
//  *  remove some personal control on where the final output goes, but        *
//  *  taking this as a constraint and designing an output for all cases       *
//  *  was possible. Adding in code to siphon the cout statements away from    *
//  *  the screen to the output.txt file allowed me and the user to have a     *
//  *  final print out of their family tree. I added the function of editing   *
//  *  a persons data so that mistakes during user input could be corrected    *
//  *  later on. It does not have the capability to modify the parents or      *
//  *  children but that capability could be added with a lot more time.       *
//  *  At the very end of the program a print out of the family tree is        *
//  *  stored into the file output.txt for later viewing. It is possible to    *
//  *  take such a file and turn it into a input.txt and have the program load *
//  *  a previously made family tree for editting, viewing, or adding; however *
//  *  that was not in the scope of this project.                              *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *              https://github.com/WilliamJHeine/Final-Project              *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  * Style Guide - Code: 80 columns, convert tabs to spaces, tab is 2 spaces, *
//  *               To be determined                                           *
//  *                                                                          *
//  * Style Guide - Print: 80 columns, 64 row title page, print line numbers,  *
//  *               header of full path file name and date printed,            *
//  *               footer of page number                                      *
//64****************************************************************************

//								//
//---Remove Secure Warnings-----//
//								//
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

//								//
//---preprocessor directive-----//
//								//
#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include "FamilyTree.h"

//									//
//---using the standard library-----//
//									//
using namespace std;

//									 //
//---Class Function addChild Def-----//
//									 //
Person *Person::addChild(string name, Gender g)
{
	Person *child = new Person(name, g);
	child->addParent(this);
	children.push_back(child);
	return child;
}

//									 //
//---Class Function addChild Def-----//
//									 //
Person *Person::addChild(Person* child)
{
	child->addParent(this);
	children.push_back(child);
	return child;
}

//									  //
//---Class Function getParent Def-----//
//									  //
Person *Person::getParent(int k) const
{
	if (k < 0 || k >= parents.size())
	{
		cout << setw(5) << " " << "Error indexing parents vector.\n";
		exit(1);
	}
	return parents[k];
}

//									 //
//---Class Function getChild Def-----//
//									 //
Person *Person::getChild(int k) const
{
	if (k < 0 || k >= children.size())
	{
		cout << setw(5) << " " << "Error indexing childrens vector.\n";
		exit(1);
	}
	return children[k];
}

//						  //
//---ostream overload-----//
//				  		  //
ostream & operator <<(ostream & out, Person p)
{
	//person
	out << "<person name = " << p.name << "(";
	if (p.gender == 0)
	{
		out << "m)\n";
	}
	else
	{
		out << "f)\n";
	}
	//their parents
	if (p.parents.size() > 0)
		out << "-----<parents>" << " ";
	for (int k = 0; k < p.parents.size(); k++)
	{
		if (p.parents[k]->gender == male)
		{
			out << "Father:";
		}
		else
		{
			out << "Mother:";
		}
		out << " " << p.parents[k]->name << "   ";
	}
	if (p.parents.size() > 0)
		out << " </parents>\n";
	//their children
	if (p.children.size() > 0)
		out << "-----<children>" << " ";
	for (int k = 0; k < p.children.size(); k++)
	{
		if (p.children[k]->gender == male)
		{
			out << "Son:";
		}
		else
		{
			out << "Daughter:";
		}
		out << " " << p.children[k]->name << "   ";
	}
	if (p.children.size() > 0)
		out << " </children>\n";
	out << "----------</person>\n\n";
	return out;
}

//					//
//---prototypes-----//
//					//
void displayHeader();
void displayMainMenu();
int choiceInput();
void error();
void exponential(int, double);

//						//
//---Main Function------//
//						//
int main(int argc, char** argv)
{
	int MenuChoice = 0,
		value1 = 0,
		value2 = 0,
		value3 = 0;

	double needPoints = 0.0;

	string nameHolder;
	string genderHolder;
	string fatherHolder;
	string motherHolder;
	string childHolder;

	Gender gender;

	vector<Person *>allPeople;

	cout << fixed << showpoint << setprecision(2);

	while (true)
	{
		MenuChoice = choiceInput();

		switch (MenuChoice)
		{
		case 1:	//people adder case
				//allows for people input by gathering the input data
				//then creating a new person in the vector
			while (true)
			{
				system("CLS");
				displayHeader();
				cout << setw(25) << " " << "Add a Person\n\n";
				nameHolder = " ";
				cout << setw(5) << " " << "Enter nothing for the name to stop adding people.\n\n";
				cout << setw(5) << " " << "Enter a name: ";
				cin.ignore();
				getline(cin, nameHolder);

				if (nameHolder.empty())
				{
					break;
				}

				cout << setw(5) << " " << "Enter their gender: ";
				cin >> genderHolder;
				if (genderHolder == "male" || genderHolder == "Male" || genderHolder == "m" || genderHolder == "M")
				{
					gender = male;
				}
				else
				{
					gender = female;
				}
				try
				{
					allPeople.push_back(new Person(nameHolder, gender));
				}
				catch(bad_alloc)
				{
					system("CLS");
					cout << "\n\n\n\n\n\n" << setw(5) << " " << "memory could not be allocated...";
					exit(1);
				}

				cout << "\n" << setw(5) << " " << "Operation complete.\n";
				system("pause");
			}
			break;

		case 2:	//people linker case
				//takes people created in case 1 and adds relationships
				//to all 3 of the input names
			{
				system("CLS");
				displayHeader();
				cout << setw(25) << " " << "Link People\n\n";
				cout << setw(5) << " ";
				for (int x = 0; x < allPeople.size(); x++)
				{
					cout << setw(12) << left << allPeople[x]->getName() << " : ";
					if ((x + 1) % 5 == 0)
					{
						cout << "\n" << setw(5) << " ";
					}
				}
				//association
				cout << "\n\n";
				cout << setw(5) << " " << "Select the parents from the list and\n" << setw(10) << " " << "link them to their child.\n\n";
				cout << setw(5) << " " << "enter nothing to exit.\n\n";
				{
					cout << setw(5) << " " << "Enter the Father's name: ";
					cin.clear();
					cin.ignore(100, '\n');
					getline(cin, fatherHolder);

					if (fatherHolder.empty())
					{
						break;
					}

					cout << setw(5) << " " << "Enter the Mother's name: ";
					getline(cin, motherHolder);
					cout << setw(5) << " " << "Enter the Child's name: ";
					getline(cin, childHolder);
					/// ????? I need to search the vector for the input names to
					/// to record the location of the names in the vector
					value1 = value2 = value3 = -1;

					for (int x = 0; x < allPeople.size(); x++)
					{
						//father name check
						if (fatherHolder.compare(allPeople[x]->getName()) == 0)
						{
							value1 = x;
						}
						//mother name check
						if (motherHolder.compare(allPeople[x]->getName()) == 0)
						{
							value2 = x;
						}
						//child name check
						if (childHolder.compare(allPeople[x]->getName()) == 0)
						{
							value3 = x;
						}

					}
					if (value1 == value2 || value1 == value3 || value2 == value3 )
					{
						cout << "\n\n";
						cout << setw(5) << " " << "Double Entry, returning to main menu.\n";
						system("pause");
						break;
					}
					if (value1 == -1 || value2 == -1 || value3 == -1)
					{
						cout << "\n\n";
						cout << setw(5) << " " << "Failed Entry, returning to main menu.\n";
						system("pause");
						break;
					}
					//father
					allPeople[value1]->addChild(allPeople[value3]);
					auto result1 = std::find(std::begin(allPeople), std::end(allPeople), allPeople[value1]);
					if (result1 != std::end(allPeople))
					{
						cout << setw(5) << " " << "The tree contains: " << fatherHolder << "\n";
					}
					else
					{
						cout << setw(5) << " " << "The tree does not contain: " << fatherHolder << "\n";
					}
					//mother
					allPeople[value2]->addChild(allPeople[value3]);
					auto result2 = std::find(std::begin(allPeople), std::end(allPeople), allPeople[value1]);
					if (result2 != std::end(allPeople))
					{
						cout << setw(5) << " " << "The tree contains: " << motherHolder << "\n";
					}
					else
					{
						cout << setw(5) << " " << "The tree does not contain: " << motherHolder << "\n";
					}

					cout << "\n" << setw(5) << " " << "Operation complete.\n";
					system("pause");
				}
			}
			break;

		case 3:	//the edit case
				//uses parts from both of the above operations
				//to take input, locate, and then change the class data
			while (true)
			{
				///list output
				system("CLS");
				displayHeader();
				cout << setw(25) << " " << "Edit Person\n\n";
				cout << setw(5) << " ";
				for (int x = 0; x < allPeople.size(); x++)
				{
					cout << setw(12) << left << allPeople[x]->getName() << " : ";
					if ((x + 1) % 5 == 0)
					{
						cout << "\n" << setw(5) << " ";
					}
				}
				cout << "\n\n";
				///user input
				cout << setw(5) << " " << "Enter nothing for the name to stop editing people.\n\n";
				cout << setw(5) << " " << "Enter the incorrect name to edit: ";
				cin.ignore();
				getline(cin, nameHolder);

				if (nameHolder.empty())
				{
					break;
				}
				///search
				value1 = -1;

				for (int x = 0; x < allPeople.size(); x++)
				{
					//Person name check
					if (nameHolder.compare(allPeople[x]->getName()) == 0)
					{
						value1 = x;
					}
				}
				if (value1 == -1)
				{
					cout << "\n\n";
					cout << setw(5) << " " << "No Entry Found, returning to main menu.\n";
					system("pause");
					break;
				}
				///edit
				cout << setw(5) << " " << "Enter the correct name: ";
				getline(cin, nameHolder);
				cout << setw(5) << " " << "Enter their gender: ";
				cin >> genderHolder;
				if (genderHolder == "male" || genderHolder == "Male" || genderHolder == "m" || genderHolder == "M")
				{
					gender = male;
				}
				else
				{
					gender = female;
				}
				allPeople[value1]->editNameGender(nameHolder, gender);
			}
			break;

		case 4:	//the tree display case
				//uses the overloaded ostream to output a person's data
				//in the form denoted in the overload
			system("CLS");
			displayHeader();

			needPoints = allPeople.size();
			cout << setw(5) << " " << static_cast<int>(needPoints) << " people are in this tree.\n\n";
			exponential(0, needPoints);

			cout << setw(5) << " " << "Here is the current list of people in the tree.\n\n";
			for (int x = 0; x < allPeople.size(); x++)
			{
				cout << *(allPeople[x]);
			}
			cout << setw(5) << " ";
			system("pause");

			break;

		case 5:	//the exit case
			cout << "\n\n\n\n\n";
			cout << setw(5) << " ";
			system("pause");

			//write to file
			freopen("output.txt", "w", stdout);

			needPoints = allPeople.size();
			cout << setw(5) << " " << static_cast<int>(needPoints) << " people are in this tree.\n\n";

			for (int x = 0; x < allPeople.size(); x++)
			{
				cout << *(allPeople[x]);
			}
			//end write to file

			exit(0);
			break;

		default:
			error();
			break;
		}
	}

	system("pause");
	return 0;
}

//Display header function
void displayHeader()
{
	cout << "\n";
	cout << setw(25) << " " << "Final Project\n";
	cout << setw(22) << " " << "by William J. Heine\n";
	cout << setw(26) << " " << "May 9, 2018\n\n";
}

//Display menu function
void displayMainMenu()
{
	cout << setw(22) << " " << "Genealogy Main Menu\n\n\n";
	cout << setw(5) << " " << "1. Add a Person\n";
	cout << setw(5) << " " << "2. Link People\n";
	cout << setw(5) << " " << "3. Edit a Person\n";
	cout << setw(5) << " " << "4. Look at the Tree\n";
	cout << setw(5) << " " << "5. Quit\n";
}

//take menuchoice input
int choiceInput()
{
	int choice = 0;

	system("CLS");
	displayHeader();
	displayMainMenu();
	//-----
	cout << "\n";
	cout << setw(5) << " " << "Enter a menu choice: ";
	cin >> choice;
	return choice;
}

//std error call for the menu
void error()
{
	system("CLS");
	displayHeader();
	cout << setw(5) << " " << "Menu selection invalid, returning to main menu.\n";
	system("pause");
	cin.clear();
	cin.ignore(100, '\n');
}

//a shoe horned recursion and cmath function
void exponential(int times, double pop)
{
	if (times < 3)
	{
		cout << setw(5) << " " << "A family of size " << static_cast<int>(pop) << " would grow to be ";
		cout << (static_cast<int>(pop * exp(.015 * pow(10, (times + 1)))));
		cout << " after " << static_cast<int>(pow(10, (times + 1))) << " years.\n";

		pop = (pop * exp(.015 * pow(10, (times + 1))));
		times++;

		exponential(times, pop);
	}
}